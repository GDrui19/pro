<table class="table table-striped">
    <thead>
    <tr>
        <th>题干ID</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>esgeshwe5h</td>
    </tr>
    </tbody>
</table>