<ul class="breadcrumb">
    <li><a href="#">试题管理</a></li>
    <li class="active">试题列表</li>
</ul>
<div style="float: right">
    <p><button type="button" class="btn btn-info" onclick="javascript:window.location='index.php?r=exam/show';">试题导入</button></p>
</div>

<table class="table table-bordered">
    <!--        <caption></caption>-->
    <thead>
    <tr>
        <th>题干ID</th>
        <th>题干</th>
        <th>月份</th>
        <th>单元</th>
        <th>类型</th>
        <th>时间</th>
        <th>出题人</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody>
    <?php
    foreach ($data as $key=>$v){
    ?>
    <tr>
        <td><?php echo $v['topic_id']?></td>
        <td><?=$v['topic_title']?></td>
        <td><?=$v['topic_month']?></td>
        <td><?=$v['topic_dy']?></td>
        <td>
            <?php
            if($v['topic_type'] == 'p-1'){
                echo '单选题';
            }elseif ($v['topic_type'] == 'p-2'){
                echo '多选题';
            }else{
                echo '判断题';
            }
            ?></td>
        <td><?=$v['topic_time']?></td>
        <td><?=$v['topic_name']?></td>
        <td>
            <button type="button" class="btn btn-info" onclick="javascript:window.location='index.php?r=exam/show';">删除</button>
        </td>
    </tr>
    <?php }?>
    </tbody>
</table>
<div style="float: right">
    <a class="btn btn-danger" href="index.php?r=exam/index&page=<?php echo $page=1?>" role="button">首页</a>

</div>