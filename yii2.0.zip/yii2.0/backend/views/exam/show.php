
<ul class="breadcrumb">
    <li><a href="#">试题管理</a></li>
    <li class="active">试题导入</li>
</ul>

<p>
    <button type="button" class="btn btn-info" onclick="javascript:window.location='index.php?r=exam/index';">试题列表</button>
</p>
<form role="form" action="index.php?r=
exam/show" method="post" enctype="multipart/form-data">
    <!--    <input type="hidden" name="r" value="index.php?">-->
    <div class="form-group">
        <label for="name">名称</label>
        <select name="name" id="">
            <option value="">请选择单元</option>
            <?php foreach (Yii::$app->params['unit'] as $k=>$v){?>
                <option value="<?=$k;?>"><?=$v;?></option>
            <?php }?>
        </select>
    </div>
    <div class="form-group">
        <label for="inputfile">文件输入</label>
        <input type="file" id="inputfile" name="excel">
    </div>
    <button type="submit" class="btn btn-default">提交</button>
</form>