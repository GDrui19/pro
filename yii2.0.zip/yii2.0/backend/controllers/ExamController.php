<?php
/**
 * Created by PhpStorm.
 * User: 丁丁
 * Date: 2018/11/12
 * Time: 18:24
 */

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use common\libs\curl;
class ExamController extends Controller
{
    public $enableCsrfValidation = false;

    public function actionIndex(){
        header("content-type:text/html;charset=utf-8");
        $url = 'http://47.93.240.214/yii2.0/api/web/index.php?r=exam/getindex';
        $data = curl::_get($url);
        $data = json_decode($data,true);
        $count = ['count'=>$data['count']];

        //var_dump($count);exit;

        return $this->render('index',['data'=>$data['data']]);
    }
    public function actionShow(){
//        require(__DIR__ . '/../../common/libs/PHPExcel.php');
//        $excel = new \PHPExcel();
        //var_dump($excel);exit;
        if(Yii::$app->request->isPost){
            $dir = '/phpstudy/www/yii2.0/backend/upload/excel.xlsx';
           $reg = move_uploaded_file($_FILES['excel']['tmp_name'],$dir);

           if($reg){
               header("content-type:text/html;charset=utf-8");
                $url = 'http://47.93.240.214/yii2.0/api/web/index.php?r=exam/import';
                $param['name'] = Yii::$app->request->get('name');
                //var_dump($param['name']);exit;
                $file['excel'] = $dir;
                $reg = curl::_post($url,$param,$file);
               if($reg){
                  return $this->redirect('index.php?r=exam/index');
               }
           }
        }else{
            return $this->render('show');
        }
    }
    //首页题
    public function actionFirst(){
        return $this->render('first');
    }
}