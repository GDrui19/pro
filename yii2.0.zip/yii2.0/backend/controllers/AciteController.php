<?php
/**
 * Created by PhpStorm.
 * User: 郭丁
 * Date: 2018/11/13
 * Time: 8:17
 */

namespace backend\controllers;

use Yii;
use yii\web\Controller;
class AciteController extends Controller
{
    public function actionIndex(){
        //$get = Yii::$app->request->get();
        $sql = "select * from comment";
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        //var_dump($data);exit;
        return $this->render('index',['data'=>$data]);

    }
    public function actionReply(){
        return $this->render('reply');
    }
}