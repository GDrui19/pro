<?php
/**
 * Created by PhpStorm.
 * User: 郭丁
 * Date: 2018/11/12
 * Time: 19:51
 */

namespace api\controllers;

use Yii;
use yii\web\Controller;
class ExamController extends Controller
{
    public $enableCsrfValidation = false;

    public function actionGetindex(){
        header("content-type:text/html;charset=utf-8");
        $page = Yii::$app->request->get('page',1);
        //每页显示的条数
        $size = Yii::$app->request->get('size',5);
        //偏移量
        $limit = ($page-1)*$size;
        //查询出总条数
        $count = Yii::$app->db->createCommand('select count(1) count from topic ')->queryOne();
        //获取总条数
        $sql = 'select * from topic limit '.$limit.','.$size;
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        //var_dump($data);exit;
        $return = array(
            'count'=>$count,
            'data'=>$data
        );
        echo json_encode($return);
    }
    //导入数据入库
    public function actionImport(){
        header("content-type:text/html;charset=utf-8");
        //var_dump($_FILES);exit;
        $dir = '/phpstudy/www/yii2.0/api/upload/excel.xlsx';
        //$reg = move_uploaded_file($_FILES['excel']['tmp_name'],$dir);
        //$name = Yii::$app->request->post('name');
        require(__DIR__ . '/../../common/libs/PHPExcel.php');
        //$excel = new \PHPExcel();
        $objPHPExcel = \PHPExcel_IOFactory::load($dir);
        //var_dump($objPHPExcel);exit;
        $sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
        //var_dump($sheetData);exit;
        $type = array_flip(Yii::$app->params['type']);
        $score = Yii::$app->params['score'];

        foreach($sheetData as $key=>$v){
            $array=array(
                'topic_title'=>$v['C'],//题干
                'topic_type'=>$type[$v['B']],//类型
                'topic_month'=>'10',//月份
                'topic_dy'=>$v['A'],//单元
                'topic_time'=>time(),//时间
//                'topic_sorce'=>$score[$type[$v['B']]],//分值
                'topic_name'=>'本人'
            );
            var_dump($array);exit;
            $data = Yii::$app->db->createCommand()->insert('topic',$array)->execute();
            //var_dump($data);
            $id = Yii::$app->db->getLastInsertID();
            $an_num = array("D"=>'A',"E"=>'B',"F"=>'C',"G"=>'D','H'=>'E','I'=>'F');

            $yes = str_split($v['J'],1);
            //题号
            for ($i='D';$i<='I';$i++){
                if (empty($v[$i]))continue;
                $is_yes = in_array($an_num[$i],$yes)?1:0;
                $answer = array(
                    'topic_id'=>$id,
                    'answer_da'=>$v[$i],
                    'answer_pd'=>$is_yes
                );
                $datas = Yii::$app->db->createCommand()->insert('answer',$answer)->execute();
            }
        }
    }
}