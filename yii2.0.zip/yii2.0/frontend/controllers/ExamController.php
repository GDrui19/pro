<?php
/**
 * Created by PhpStorm.
 * User: 郭丁
 * Date: 2018/11/15
 * Time: 11:03
 */

namespace frontend\controllers;

use Yii;
use yii\web\Controller;
class ExamController extends Controller
{
    public $enableCsrfValidation = false;
    public function actionIndex(){
        return $this->render('index');
    }
    public function actionList(){
        var_dump($_GET);exit;
    }
}