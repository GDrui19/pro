<?php
return [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'qThWuO_daC3Sz3B7jKCiAtbpgODWKz2j',
        ],
    ],
];
