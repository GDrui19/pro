<form action="index.php">
    <input type="hidden" name="r" value="exam/list">
    <?php foreach (Yii::$app->params['month'] as $k=>$v){?>
        <input type="checkbox" name=""><?=$v;?><br/>
        <?php foreach (Yii::$app->params['unit'] as $key=>$val) {?>
            &nbsp;&nbsp;&nbsp;<input type="checkbox" name=""><?=$val;?>
        <?php }?>
        <br>
    <?php }?>
    <input type="submit" value="提交">
</form>
