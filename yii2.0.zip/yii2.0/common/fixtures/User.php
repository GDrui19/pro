<?php
namespace common\fixtures;

use yii\test\ActiveFixture;

class User extends ActiveFixture
{
    public $modelClass = 'common\models\User';
}